import React, {useState, useEffect} from 'react';
import { db } from './services/firebase';
import { collection, getDocs, query, orderBy } from 'firebase/firestore';

export default function App(){
  const [properties,setProperties] = useState([]);
  useEffect(()=>{
    async function fetch(){
      const q = query(collection(db,'properties'), orderBy('publishedAt','desc'));
      const snap = await getDocs(q);
      setProperties(snap.docs.map(d=>({id:d.id,...d.data()})));
    }
    fetch();
  },[]);
  return (
    <div className='app'>
      <header className='hero'>مهرشهرملک</header>
      <main>
        <div className='grid'>
          {properties.map(p=>(
            <div key={p.id} className='card'>
              <img src={p.images?.[0] || ''} alt={p.title} />
              <h3>{p.title}</h3>
              <p>{p.price} تومان</p>
              <p>{p.region} - {p.area}</p>
            </div>
          ))}
        </div>
      </main>
    </div>
  )
}
