# MehrshahrMelk — Full Project Skeleton (Mobile, Web, Server)

این بسته شامل اسکلت کامل پروژه مهرشهرملک برای:
- موبایل (Expo React Native)
- وب (React PWA)
- سرور نمونه (Node.js/Express برای Stripe webhooks)

**نکته‌ها:**
- مقادیر کلیدها (Firebase, Google Maps, Stripe) به صورت placeholder هستند. بعد از دانلود و قبل از اجرا، آن‌ها را جایگزین کنید.
- برای ساخت نسخه‌های production و انتشار در فروشگاه‌ها نیاز به پیکربندی اضافی (keystore, App Store Connect, Play Console) دارید.

## پوشه‌ها
- mobile/    => اپ موبایل (Expo)
- web/       => اپ وب (Create React App)
- functions/ => سرور نمونه (Stripe)

## اجرا (محلی)
### موبایل
```bash
cd mobile
npm install
expo start
```

### وب
```bash
cd web
npm install
npm start
```

### functions
```bash
cd functions
npm install
node index.js
```

