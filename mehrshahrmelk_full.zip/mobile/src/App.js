import React, { useEffect, useState } from 'react';
import { NavigationContainer } from '@react-navigation/native';
import MainStack from './navigation';
import { auth } from './services/firebase';
import { onAuthStateChanged } from 'firebase/auth';
import { Provider as PaperProvider } from 'react-native-paper';

export default function App(){
  const [user, setUser] = useState(null);
  useEffect(()=>{
    const unsub = onAuthStateChanged(auth, u=> setUser(u));
    return ()=> unsub();
  },[]);

  return (
    <PaperProvider>
      <NavigationContainer>
        <MainStack user={user} />
      </NavigationContainer>
    </PaperProvider>
  );
}
