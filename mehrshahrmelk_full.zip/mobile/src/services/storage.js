import { ref, uploadBytes, getDownloadURL } from 'firebase/storage';
import { storage } from './firebase';

export async function uploadImageAsync(uri){
  const response = await fetch(uri);
  const blob = await response.blob();
  const fileName = `property_images/${Date.now()}_${Math.random().toString(36).substr(2,9)}.jpg`;
  const storageRef = ref(storage, fileName);
  await uploadBytes(storageRef, blob);
  const url = await getDownloadURL(storageRef);
  return url;
}
