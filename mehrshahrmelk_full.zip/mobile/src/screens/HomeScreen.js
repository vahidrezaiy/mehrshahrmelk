import React, {useEffect, useState} from 'react';
import { View, Text, FlatList, TouchableOpacity, TextInput } from 'react-native';
import { collection, getDocs, query, orderBy } from 'firebase/firestore';
import { db } from '../services/firebase';
import PropertyCard from '../components/PropertyCard';

export default function HomeScreen({navigation}){
  const [properties,setProperties] = useState([]);
  const [search,setSearch] = useState('');

  const fetch = async ()=>{
    const q = query(collection(db,'properties'), orderBy('publishedAt','desc'));
    const snap = await getDocs(q);
    setProperties(snap.docs.map(d=>({id:d.id,...d.data()})));
  }
  useEffect(()=>{ fetch(); },[]);

  const filtered = properties.filter(p => p.title.includes(search) || p.region?.includes(search) );

  return (
    <View style={{flex:1,padding:12}}>
      <View style={{flexDirection:'row',marginBottom:10}}>
        <TextInput placeholder="جستجو" value={search} onChangeText={setSearch} style={{flex:1,borderWidth:1,padding:8,borderRadius:8}} />
        <TouchableOpacity onPress={()=>navigation.navigate('AddProperty')} style={{marginLeft:8,backgroundColor:'#ff6a00',padding:10,borderRadius:8}}>
          <Text style={{color:'#fff'}}>افزودن</Text>
        </TouchableOpacity>
      </View>
      <FlatList
        data={filtered}
        keyExtractor={item=>item.id}
        renderItem={({item}) => <PropertyCard p={item} onPress={()=>navigation.navigate('Details',{id:item.id})} />}
      />
    </View>
  );
}
