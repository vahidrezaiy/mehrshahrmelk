import React, {useState} from 'react';
import { View, TextInput, Button, ScrollView, Text } from 'react-native';
import * as ImagePicker from 'expo-image-picker';
import { collection, addDoc } from 'firebase/firestore';
import { db } from '../services/firebase';
import { uploadImageAsync } from '../services/storage';

export default function AddPropertyScreen({navigation}){
  const [title,setTitle] = useState('');
  const [price,setPrice] = useState('');
  const [type,setType] = useState('آپارتمان');
  const [subtype,setSubtype] = useState('فروش');
  const [statusDocs,setStatusDocs] = useState('سند رسمی');
  const [address,setAddress] = useState('');
  const [images,setImages] = useState([]);

  const pickImage = async ()=>{
    const res = await ImagePicker.launchImageLibraryAsync({mediaTypes:ImagePicker.MediaTypeOptions.Images,quality:0.7});
    if(res.canceled || !res.assets) return;
    const uri = res.assets[0].uri;
    const url = await uploadImageAsync(uri);
    setImages(prev=>[...prev,url]);
  }

  const submit = async ()=>{
    const doc = {
      title, price: Number(price), type, subtype, statusDocs, address,
      images, publishedAt: Date.now(), region: 'مهرشهر', area: 'فاز 2'
    };
    try{
      await addDoc(collection(db,'properties'), doc);
      navigation.goBack();
    }catch(e){ alert(e.message) }
  }

  return (
    <ScrollView style={{padding:12}}>
      <Text>عنوان</Text>
      <TextInput value={title} onChangeText={setTitle} style={{borderWidth:1,padding:8,marginBottom:8}} />
      <Text>قیمت</Text>
      <TextInput value={price} onChangeText={setPrice} keyboardType='numeric' style={{borderWidth:1,padding:8,marginBottom:8}} />
      <Text>نوع</Text>
      <TextInput value={type} onChangeText={setType} style={{borderWidth:1,padding:8,marginBottom:8}} />
      <Text>زیرنوع</Text>
      <TextInput value={subtype} onChangeText={setSubtype} style={{borderWidth:1,padding:8,marginBottom:8}} />
      <Text>وضعیت سند</Text>
      <TextInput value={statusDocs} onChangeText={setStatusDocs} style={{borderWidth:1,padding:8,marginBottom:8}} />
      <Text>آدرس</Text>
      <TextInput value={address} onChangeText={setAddress} style={{borderWidth:1,padding:8,marginBottom:8}} />

      <Button title="انتخاب عکس" onPress={pickImage} />
      <Text>تعداد عکس‌ها: {images.length}</Text>
      <Button title="ثبت ملک" onPress={submit} />
    </ScrollView>
  );
}
