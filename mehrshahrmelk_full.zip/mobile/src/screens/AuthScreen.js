import React, {useState} from 'react';
import { View, Text, TextInput, Button } from 'react-native';
import { createUserWithEmailAndPassword, signInWithEmailAndPassword } from 'firebase/auth';
import { auth } from '../services/firebase';

export default function AuthScreen(){
  const [email,setEmail] = useState('');
  const [password,setPassword] = useState('');
  const [mode,setMode] = useState('login');

  const submit = async ()=>{
    try{
      if(mode==='login') await signInWithEmailAndPassword(auth,email,password);
      else await createUserWithEmailAndPassword(auth,email,password);
    }catch(e){
      alert(e.message);
    }
  }

  return (
    <View style={{flex:1,justifyContent:'center',padding:20}}>
      <Text style={{fontSize:24,textAlign:'center'}}>مهرشهرملک</Text>
      <TextInput placeholder="ایمیل" value={email} onChangeText={setEmail} style={{borderWidth:1,marginVertical:10,padding:8}} />
      <TextInput placeholder="رمز" value={password} onChangeText={setPassword} secureTextEntry style={{borderWidth:1,marginVertical:10,padding:8}} />
      <Button title={mode==='login'?'ورود':'ثبت نام'} onPress={submit} />
      <Button title={mode==='login'?'رفتن به ثبت نام':'بازگشت به ورود'} onPress={()=>setMode(mode==='login'?'register':'login')} />
    </View>
  );
}
