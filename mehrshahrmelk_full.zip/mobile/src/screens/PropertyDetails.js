import React, {useEffect, useState} from 'react';
import { View, Text, Image, ScrollView } from 'react-native';
import { doc, getDoc } from 'firebase/firestore';
import { db } from '../services/firebase';

export default function PropertyDetails({route}){
  const {id} = route.params;
  const [prop,setProp] = useState(null);
  useEffect(()=>{
    (async ()=>{
      const d = await getDoc(doc(db,'properties',id));
      setProp({id:d.id,...d.data()});
    })();
  },[]);

  if(!prop) return <Text>در حال بارگذاری...</Text>;
  return (
    <ScrollView style={{padding:12}}>
      <Text style={{fontSize:20,fontWeight:'bold'}}>{prop.title}</Text>
      <Text>{prop.price} تومان</Text>
      <Text>{prop.address}</Text>
      {prop.images?.map((u,i)=> <Image key={i} source={{uri:u}} style={{width:'100%',height:200,marginVertical:6}} />)}
      <Text>نوع: {prop.type} - {prop.subtype}</Text>
      <Text>وضعیت سند: {prop.statusDocs}</Text>
    </ScrollView>
  );
}
