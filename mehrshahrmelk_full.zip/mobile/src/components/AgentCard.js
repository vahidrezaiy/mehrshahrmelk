import React from 'react';
import { View, Text, TouchableOpacity } from 'react-native';

export default function AgentCard({agent,onPress}){
  return (
    <TouchableOpacity onPress={onPress} style={{padding:12,borderRadius:8,backgroundColor:'#fdf7f0',marginBottom:8}}>
      <Text style={{fontWeight:'bold'}}>{agent.name}</Text>
      <Text>{agent.phone}</Text>
    </TouchableOpacity>
  );
}
