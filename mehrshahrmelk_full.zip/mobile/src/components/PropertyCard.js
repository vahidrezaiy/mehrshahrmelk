import React from 'react';
import { View, Text, Image, TouchableOpacity } from 'react-native';

export default function PropertyCard({p,onPress}){
  return (
    <TouchableOpacity onPress={onPress} style={{marginBottom:12,borderRadius:12,overflow:'hidden',backgroundColor:'#fff',elevation:2}}>
      {p.images?.[0] && <Image source={{uri:p.images[0]}} style={{height:160,width:'100%'}} />}
      <View style={{padding:10}}>
        <Text style={{fontSize:16,fontWeight:'bold'}}>{p.title}</Text>
        <Text style={{color:'#ff6a00',marginTop:6}}>{p.price} تومان</Text>
        <Text style={{color:'#666',marginTop:6}}>{p.region} - {p.area}</Text>
      </View>
    </TouchableOpacity>
  );
}
