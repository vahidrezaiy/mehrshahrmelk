import React from 'react';
import { createStackNavigator } from '@react-navigation/stack';
import HomeScreen from '../screens/HomeScreen';
import AddPropertyScreen from '../screens/AddPropertyScreen';
import PropertyDetails from '../screens/PropertyDetails';
import AuthScreen from '../screens/AuthScreen';

const Stack = createStackNavigator();

export default function MainStack({user}){
  return (
    <Stack.Navigator>
      {!user ? (
        <Stack.Screen name="Auth" component={AuthScreen} options={{headerShown:false}} />
      ) : (
        <>
          <Stack.Screen name="Home" component={HomeScreen} />
          <Stack.Screen name="AddProperty" component={AddPropertyScreen} options={{title:'افزودن ملک'}} />
          <Stack.Screen name="Details" component={PropertyDetails} options={{title:'جزئیات'}} />
        </>
      )}
    </Stack.Navigator>
  );
}
